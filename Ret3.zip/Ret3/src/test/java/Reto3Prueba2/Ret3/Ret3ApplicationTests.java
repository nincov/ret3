package Reto3Prueba2.Ret3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ret3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
