package Reto3Prueba2.Ret3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ret3Application {

	public static void main(String[] args) {
		SpringApplication.run(Ret3Application.class, args);
	}

}
